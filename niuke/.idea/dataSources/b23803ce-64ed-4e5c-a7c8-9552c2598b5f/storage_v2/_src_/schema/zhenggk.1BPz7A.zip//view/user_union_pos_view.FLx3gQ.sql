create view user_union_pos_view as
select `u`.`user_id`       AS `user_id`,
       `u`.`user_name`     AS `user_name`,
       `u`.`user_status`   AS `user_status`,
       `p`.`position_code` AS `position_code`,
       `p`.`position_name` AS `position_name`,
       `u`.`org_id`        AS `org_id`,
       `p`.`org_id`        AS `pos_org_id`
from `zhenggk`.`tsys_position` `p`
         join `zhenggk`.`tsys_user` `u`
where `u`.`approval_status` is null
   or `u`.`approval_status` <> '1';

