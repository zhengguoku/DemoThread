create view space_user_view as
select `s`.`env_id`      AS `env_id`,
       `u`.`user_id`     AS `user_id`,
       `u`.`user_name`   AS `user_name`,
       `u`.`org_id`      AS `org_id`,
       `u`.`user_status` AS `user_status`,
       `u`.`user_type`   AS `user_type`,
       `o`.`org_name`    AS `org_name`
from ((`zhenggk`.`tsys_user` `u` left join `zhenggk`.`tsys_space_user` `s` on (`s`.`user_id` = `u`.`user_id`))
         join `zhenggk`.`tsys_organization` `o` on (`o`.`status` >= 0 and `u`.`org_id` = `o`.`org_id`))
where (`u`.`approval_status` is null or `u`.`approval_status` <> '1')
  and (`o`.`approval_status` is null or `o`.`approval_status` <> '1');

