create view org_user_view as
select `u`.`org_id` AS `org_id`, `u`.`user_id` AS `user_id`
from `zhenggk`.`tsys_user` `u`
union
select `ou`.`org_id` AS `org_id`, `ou`.`user_id` AS `user_id`
from `zhenggk`.`tsys_org_user` `ou`;

