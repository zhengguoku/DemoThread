create view role_view as
select `r`.`role_code`  AS `role_code`,
       `r`.`role_name`  AS `role_name`,
       '2'              AS `right_flag`,
       `r`.`role_order` AS `role_order`,
       `r`.`tenant_id`  AS `tenant_id`,
       `r`.`kind_code`  AS `kind_code`
from `zhenggk`.`tsys_role` `r`
where (`r`.`approval_status` is null or `r`.`approval_status` <> '1')
  and `r`.`role_status` = '1'
union
select `r`.`role_code`  AS `role_code`,
       `r`.`role_name`  AS `role_name`,
       '1'              AS `right_flag`,
       `r`.`role_order` AS `role_order`,
       `r`.`tenant_id`  AS `tenant_id`,
       `r`.`kind_code`  AS `kind_code`
from `zhenggk`.`tsys_role` `r`
where (`r`.`approval_status` is null or `r`.`approval_status` <> '1')
  and `r`.`role_status` = '1';

