create view user_right_union_view as
select distinct `ur`.`trans_code`     AS `trans_code`,
                `ur`.`sub_trans_code` AS `sub_trans_code`,
                `ur`.`right_flag`     AS `right_flag`,
                `ur`.`user_id`        AS `user_id`
from `zhenggk`.`tsys_user_right` `ur`
where `ur`.`right_enable` is null
   or `ur`.`right_enable` in ('', '1')
union
select distinct `rr`.`trans_code`     AS `trans_code`,
                `rr`.`sub_trans_code` AS `sub_trans_code`,
                `rr`.`right_flag`     AS `right_flag`,
                `ru`.`user_code`      AS `user_id`
from `zhenggk`.`tsys_role_user` `ru`
         join `zhenggk`.`tsys_role_right` `rr`
         join `zhenggk`.`tsys_role` `r`
where `rr`.`role_code` = `ru`.`role_code`
  and `rr`.`role_code` = `r`.`role_code`
  and (`r`.`approval_status` is null or `r`.`approval_status` <> '1')
  and `r`.`role_status` = '1'
  and !exists(select 'X'
              from `zhenggk`.`tsys_user_right` `ur`
              where `ur`.`trans_code` = `rr`.`trans_code`
                and `ur`.`sub_trans_code` = `rr`.`sub_trans_code`
                and `rr`.`right_flag` = `ur`.`right_flag`
                and `ur`.`right_enable` = '0');

