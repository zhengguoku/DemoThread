create view user_pos_view as
select distinct `x0`.`position_code` AS `position_code`,
                `x0`.`position_name` AS `position_name`,
                `x0`.`parent_code`   AS `parent_code`,
                `x0`.`org_id`        AS `org_id`,
                `x0`.`role_code`     AS `role_code`,
                `x0`.`position_path` AS `position_path`,
                `x0`.`remark`        AS `remark`,
                `x0`.`ext_field_1`   AS `ext_field_1`,
                `x0`.`ext_field_2`   AS `ext_field_2`,
                `x0`.`ext_field_3`   AS `ext_field_3`,
                `x1`.`user_id`       AS `user_id`
from (`zhenggk`.`tsys_position` `x0`
         left join `zhenggk`.`tsys_pos_user` `x1` on (`x1`.`position_code` = `x0`.`position_code`));

