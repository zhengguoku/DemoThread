create view pos_user_view as
select `pos`.`org_id` AS `org_id`, `ps`.`user_id` AS `user_id`
from (`zhenggk`.`tsys_position` `pos`
         join `zhenggk`.`tsys_pos_user` `ps` on (`ps`.`position_code` = `pos`.`position_code`));

